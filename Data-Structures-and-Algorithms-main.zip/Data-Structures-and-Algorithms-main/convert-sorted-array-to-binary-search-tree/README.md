[Discussion Post (created on 1/3/2021 at 0:39)](https://leetcode.com/problems/convert-sorted-array-to-binary-search-tree/submissions/)  
<h2>108. Convert Sorted Array to Binary Search Tree</h2><h3>Easy</h3><hr><div><p>Given an array where elements are sorted in ascending order, convert it to a height balanced BST.</p>

<p>For this problem, a height-balanced binary tree is defined as a binary tree in which the depth of the two subtrees of <em>every</em> node never differ by more than 1.</p>

<p><strong>Example:</strong></p>

<pre>Given the sorted array: [-10,-3,0,5,9],

One possible answer is: [0,-3,9,-10,null,5], which represents the following height balanced BST:

      0
     / \
   -3   9
   /   /
 -10  5
</pre>
</div>